﻿using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Collections.Generic;

public class EnvironmentGenerator : MonoBehaviour
{
	public static void CreateEnvironment2D(int width, int height)
	{
		CellularAutomaton2D.PixelGrid = new GameObject[width, height];
		CellularAutomaton2D.ActionsList = new bool[width, height];

		for (int i = 0; i < width; i++)
		{
			for (int j = 0; j < height; j++)
			{
				var go = (GameObject)PrefabUtility.InstantiatePrefab(Resources.Load("Cube"));
				go.transform.position = new Vector3(i, 0, j);
				go.renderer.material.color = Color.white;
				CellularAutomaton2D.PixelGrid[i, j] = go;
			}
		}

		var cam = (GameObject)PrefabUtility.InstantiatePrefab(Resources.Load("Camera2D"));
		var lum = (GameObject)PrefabUtility.InstantiatePrefab(Resources.Load("Light"));
		cam.transform.position = new Vector3(width / 2, 10, height / 2);
		cam.camera.orthographicSize = Mathf.Max(width, height);
		lum.transform.position = new Vector3(width / 2, 10, height / 2);
	}

	public static void CreateEnvironment3D(int width, int length, int height)
	{
		CellularAutomaton3D.PixelGrid = new GameObject[width, length, height];
		CellularAutomaton3D.ActionsList = new bool[width, length, height];

		for (int i = 0; i < width; i++)
		{
			for (int j = 0; j < length; j++)
			{
				for (int k = 0; k < height; k++)
				{
					var go = (GameObject)PrefabUtility.InstantiatePrefab(Resources.Load("Cube"));
					go.transform.position = new Vector3(i, k, j);
					go.renderer.material.color = Color.white;
					CellularAutomaton3D.PixelGrid[i, j, k] = go;
				}
			}
		}

		var cam = (GameObject)PrefabUtility.InstantiatePrefab(Resources.Load("Camera3D"));
		var lum = (GameObject)PrefabUtility.InstantiatePrefab(Resources.Load("Light"));
		cam.transform.position = new Vector3(-width / 2, length, -height / 2);
		cam.camera.farClipPlane = 2 * (width + length + height) / 3;
		lum.transform.position = new Vector3(width / 2, length / 2, height / 2);
	}
}
