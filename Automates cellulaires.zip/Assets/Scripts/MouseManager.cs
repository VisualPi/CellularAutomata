﻿using UnityEngine;
using System.Collections;

public class MouseManager : MonoBehaviour
{
	Color initialColor;

	void Start()
	{
		initialColor = renderer.material.color;
	}

	void OnMouseDown()
	{
		if (initialColor == Color.black)
		{
			initialColor = Color.white;
		}
		else
		{
			initialColor = Color.black;
		}
		renderer.material.color = initialColor;
	}

	void OnMouseOver()
	{
		renderer.material.color = Color.grey;
	}

	void OnMouseExit()
	{
		renderer.material.color = initialColor;
	}
}
