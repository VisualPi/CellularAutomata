﻿using UnityEngine;
using System.Collections;

public class Common : MonoBehaviour
{

	// Use this for initialization
	void Start()
	{

	}

	// Update is called once per frame
	void Update()
	{

	}

	public static void CommonGUI(ref bool run, ref int tic)
	{
		GUI.enabled = !run;

		if (GUI.Button(new Rect(10, 10, 70, 20), "Reset"))
		{
			run = false;
			Application.LoadLevel(0);
		}

		if (GUI.Button(new Rect(10, 40, 70, 20), "Run"))
		{
			run = true;
		}

		GUI.enabled = run;

		if (GUI.Button(new Rect(10, 70, 70, 20), "Stop"))
		{
			run = false;
		}

		GUI.enabled = !(tic == 2);

		if (GUI.Button(new Rect(10, 100, 30, 20), "-"))
		{
			tic /= 2;
		}

		GUI.enabled = !(tic == 1024);

		if (GUI.Button(new Rect(50, 100, 30, 20), "+"))
		{
			tic *= 2;
		}

		GUI.enabled = true;
		GUI.Label(new Rect(10, 130, 70, 20), string.Format("Tic = {0} milliseconds.", tic.ToString()));
	}
}
