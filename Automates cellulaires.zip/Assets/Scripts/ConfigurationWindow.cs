﻿using UnityEngine;
using System.Collections;

public class ConfigurationWindow : MonoBehaviour
{
	private static string Width { get; set; }
	private static string Length { get; set; }
	private static string Height { get; set; }

	void Start()
	{
		Width = "10";
		Length = "10";
		Height = "10";
	}

	public void OnGUI()
	{
		GUILayout.BeginVertical();

		GUILayout.BeginHorizontal();
		GUILayout.Label("Width : ");
		Width = GUILayout.TextField(Width);
		GUILayout.EndHorizontal();

		GUILayout.BeginHorizontal();
		GUILayout.Label("Length : ");
		Length = GUILayout.TextField(Length);
		GUILayout.EndHorizontal();

		GUILayout.BeginHorizontal();
		GUILayout.Label("Height : ");
		Height = GUILayout.TextField(Height);
		GUILayout.EndHorizontal();

		if (GUILayout.Button("Run2D"))
		{
			CellularAutomaton2D.Height = int.Parse(Height);
			CellularAutomaton2D.Width = int.Parse(Width);
			Application.LoadLevel("MainScene2D");
		}

		if (GUILayout.Button("Run3D"))
		{
			CellularAutomaton3D.Height = int.Parse(Height);
			CellularAutomaton3D.Length = int.Parse(Length);
			CellularAutomaton3D.Width = int.Parse(Width);
			Application.LoadLevel("MainScene3D");
		}

		GUILayout.EndVertical();
	}
}
