﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using UnityEngine;

public class CellularAutomaton3D : MonoBehaviour
{

	public static GameObject[, ,] PixelGrid { get; set; }
	public static bool[, ,] ActionsList { get; set; }

	public static int Width { get; set; }
	public static int Length { get; set; }
	public static int Height { get; set; }

	private bool run;
	private int alive;

	private int tic;

	void Start()
	{
		tic = 256;
		EnvironmentGenerator.CreateEnvironment3D(Width, Length, Height);
		run = false;
	}

	void Update()
	{
		if (run)
		{
			for (int i = 0; i < Width; i++)
			{
				for (int j = 0; j < Length; j++)
				{
					for (int k = 0; k < Height; k++)
					{
						alive = 0;
						foreach (GameObject neighbour in GetNeighbours(i, k, j))
						{
							if (IsAlive(neighbour))
							{
								alive++;
							}
						}

						if (IsAlive(PixelGrid[i, k, j]))
						{
							if (alive >= 3 && alive <= 9)
							{
								ActionsList[i, k, j] = true;
							}
							else
							{
								ActionsList[i, k, j] = false;
							}
						}
						else
						{
							if (alive == 5)
							{
								ActionsList[i, k, j] = true;
							}
							else
							{
								ActionsList[i, k, j] = false;
							}
						}
					}
				}
			}

			ExecuteActions(ActionsList);
		}
	}

	void OnGUI()
	{

		Common.CommonGUI(ref run, ref tic);

		GUI.enabled = !run;
		if (GUI.Button(new Rect(10, 160, 70, 20), "Random"))
		{
			foreach (GameObject obj in PixelGrid)
			{
				obj.renderer.material.color = Color.white;
				if (Random.Range(0, 2) == 0)
				{
					obj.renderer.material.color = Color.black;
				}
			}
		}
	}

	List<GameObject> GetNeighbours(int x, int y, int z)
	{
		HashSet<GameObject> set = new HashSet<GameObject>();

		int a = x + 1 > Width - 1 ? 0 : x + 1;
		int b = x - 1 < 0 ? Width - 1 : x - 1;
		int c = y + 1 > Length - 1 ? 0 : y + 1;
		int d = y - 1 < 0 ? Length - 1 : y - 1;
		int e = z + 1 > Height - 1 ? 0 : z + 1;
		int f = z - 1 < 0 ? Height - 1 : z - 1;

		set.Add(PixelGrid[b, d, f]);
		set.Add(PixelGrid[b, d, e]);
		set.Add(PixelGrid[b, c, f]);
		set.Add(PixelGrid[b, c, e]);
		set.Add(PixelGrid[a, d, f]);
		set.Add(PixelGrid[a, d, e]);
		set.Add(PixelGrid[a, c, f]);
		set.Add(PixelGrid[a, c, e]);
		set.Add(PixelGrid[x, d, f]);
		set.Add(PixelGrid[x, d, e]);
		set.Add(PixelGrid[x, c, f]);
		set.Add(PixelGrid[x, c, e]);
		set.Add(PixelGrid[b, y, f]);
		set.Add(PixelGrid[b, y, e]);
		set.Add(PixelGrid[a, y, f]);
		set.Add(PixelGrid[a, y, e]);
		set.Add(PixelGrid[b, d, z]);
		set.Add(PixelGrid[b, c, z]);
		set.Add(PixelGrid[a, d, z]);
		set.Add(PixelGrid[a, c, z]);
		set.Add(PixelGrid[x, y, e]);
		set.Add(PixelGrid[x, y, f]);
		set.Add(PixelGrid[x, d, z]);
		set.Add(PixelGrid[x, c, z]);
		set.Add(PixelGrid[b, y, z]);
		set.Add(PixelGrid[a, y, z]);

		return set.ToList();
	}

	bool IsAlive(GameObject go)
	{
		return go.renderer.material.color == Color.black;
	}

	void GiveLife(GameObject go)
	{
		go.renderer.material.color = Color.black;
	}

	void Kill(GameObject go)
	{
		go.renderer.material.color = Color.black;
	}

	void ExecuteActions(bool[, ,] actionsList)
	{
		Thread.Sleep(tic);
		for (int i = 0; i < Width; i++)
		{
			for (int j = 0; j < Length; j++)
			{
				for (int k = 0; k < Height; k++)
				{
					if (actionsList[i, k, j])
					{
						GiveLife(PixelGrid[i, k, j]);
					}
					else
					{
						Kill(PixelGrid[i, k, j]);
					}
				}
			}
		}
	}
}
