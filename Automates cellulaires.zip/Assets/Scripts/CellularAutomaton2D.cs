﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using UnityEngine;

public class CellularAutomaton2D : MonoBehaviour
{

	public static GameObject[,] PixelGrid { get; set; }
	public static bool[,] ActionsList { get; set; }

	public static int Width { get; set; }
	public static int Length { get; set; }
	public static int Height { get; set; }

	private bool run;
	private int alive;

	private int tic;

	void Start()
	{
		tic = 256;
		EnvironmentGenerator.CreateEnvironment2D(Width, Height);
		run = false;
	}

	void Update()
	{
		if (run)
		{
			for (int i = 0; i < Width; i++)
			{
				for (int j = 0; j < Height; j++)
				{
					alive = 0;
					foreach (GameObject neighbour in GetNeighbours(i, j))
					{
						if (IsAlive(neighbour))
						{
							alive++;
						}
					}

					if (IsAlive(PixelGrid[i, j]))
					{
						if (alive == 3 || alive == 2)
						{
							ActionsList[i, j] = true;
						}
						else
						{
							ActionsList[i, j] = false;
						}
					}
					else
					{
						if (alive == 3)
						{
							ActionsList[i, j] = true;
						}
						else
						{
							ActionsList[i, j] = false;
						}
					}
				}
			}

			ExecuteActions(ActionsList);
		}
	}

	void OnGUI()
	{
		Common.CommonGUI(ref run, ref tic);

		GUI.enabled = !run;
		if (GUI.Button(new Rect(10, 160, 70, 20), "Random"))
		{
			foreach (GameObject obj in PixelGrid)
			{
				obj.renderer.material.color = Color.white;
				if (Random.Range(0, 2) == 0)
				{
					obj.renderer.material.color = Color.black;
				}
			}
		}
	}

	List<GameObject> GetNeighbours(int x, int y)
	{
		HashSet<GameObject> set = new HashSet<GameObject>();

		int a = x + 1 > Width - 1 ? 0 : x + 1;
		int b = x - 1 < 0 ? Width - 1 : x - 1;
		int c = y + 1 > Height - 1 ? 0 : y + 1;
		int d = y - 1 < 0 ? Height - 1 : y - 1;

		set.Add(PixelGrid[a, c]);
		set.Add(PixelGrid[a, y]);
		set.Add(PixelGrid[a, d]);
		set.Add(PixelGrid[x, c]);
		set.Add(PixelGrid[x, d]);
		set.Add(PixelGrid[b, c]);
		set.Add(PixelGrid[b, y]);
		set.Add(PixelGrid[b, d]);

		return set.ToList();
	}

	bool IsAlive(GameObject go)
	{
		return go.renderer.material.color == Color.black;
	}

	void GiveLife(GameObject go)
	{
		go.renderer.material.color = Color.black;
	}

	void Kill(GameObject go)
	{
		go.renderer.material.color = Color.white;
	}

	void ExecuteActions(bool[,] actionsList)
	{
		Thread.Sleep(tic);
		for (int i = 0; i < Width; i++)
		{
			for (int j = 0; j < Height; j++)
			{
				if (actionsList[i, j])
				{
					GiveLife(PixelGrid[i, j]);
				}
				else
				{
					Kill(PixelGrid[i, j]);
				}
			}
		}
	}
}
